Select CompanyName FROM Orders JOIN [Order Details] ON Orders.OrderID = [Order Details].OrderID
JOIN Customers ON Orders.CustomerID = Customers.CustomerID WHERE YEAR(OrderDate) = 1997 Group By CompanyName HAVING SUM(Quantity) > 500
