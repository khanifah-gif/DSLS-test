Select * FROM Employees

Select CONCAT(FirstName, ' ', LastName) as NamaEmployee FROM Employees WHERE Title = 'Sales Representative'