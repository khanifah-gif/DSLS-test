SELECT * FROM Orders

Select Count(CustomerID) As JumlahCustMonth1 From Orders WHERE YEAR(OrderDate) = 1997 AND Month(OrderDate) = 1
Select Count(CustomerID) As JumlahCustMonth2 From Orders WHERE YEAR(OrderDate) = 1997 AND Month(OrderDate) = 2
Select Count(CustomerID) As JumlahCustMonth3 From Orders WHERE YEAR(OrderDate) = 1997 AND Month(OrderDate) = 3
Select Count(CustomerID) As JumlahCustMonth4 From Orders WHERE YEAR(OrderDate) = 1997 AND Month(OrderDate) = 4
Select Count(CustomerID) As JumlahCustMonth5 From Orders WHERE YEAR(OrderDate) = 1997 AND Month(OrderDate) = 5
Select Count(CustomerID) As JumlahCustMonth6 From Orders WHERE YEAR(OrderDate) = 1997 AND Month(OrderDate) = 6
Select Count(CustomerID) As JumlahCustMonth7 From Orders WHERE YEAR(OrderDate) = 1997 AND Month(OrderDate) = 7
Select Count(CustomerID) As JumlahCustMonth8 From Orders WHERE YEAR(OrderDate) = 1997 AND Month(OrderDate) = 8
Select Count(CustomerID) As JumlahCustMonth9 From Orders WHERE YEAR(OrderDate) = 1997 AND Month(OrderDate) = 9
Select Count(CustomerID) As JumlahCustMonth10 From Orders WHERE YEAR(OrderDate) = 1997 AND Month(OrderDate) = 10
Select Count(CustomerID) As JumlahCustMonth11 From Orders WHERE YEAR(OrderDate) = 1997 AND Month(OrderDate) = 11
Select Count(CustomerID) As JumlahCustMonth12 From Orders WHERE YEAR(OrderDate) = 1997 AND Month(OrderDate) = 12

