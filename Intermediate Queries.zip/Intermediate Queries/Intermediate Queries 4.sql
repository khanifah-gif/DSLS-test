Select * From Orders
Select * From [Order Details]
Select * From Products
Select * From Customers

Select CompanyName From Orders
JOIN [Order Details] ON Orders.OrderID = [Order Details].OrderID
JOIN Products ON [Order Details].ProductID = Products.ProductID
JOIN Customers ON Orders.CustomerID = Customers.CustomerID
WHERE ProductName = 'Chai' AND YEAR(OrderDate) = 1997 AND MONTH(OrderDate) = 6