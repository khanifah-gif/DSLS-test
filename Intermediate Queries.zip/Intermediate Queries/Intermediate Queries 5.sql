Select * From [Order Details]

Select COUNT(DISTINCT(OrderID)) as JumlahOrderID FROM [Order Details] WHERE UnitPrice * Quantity <= 100
Select COUNT(DISTINCT(OrderID)) as JumlahOrderID FROM [Order Details] WHERE UnitPrice * Quantity > 100 AND UnitPrice * Quantity <= 250
Select COUNT(DISTINCT(OrderID)) as JumlahOrderID FROM [Order Details] WHERE UnitPrice * Quantity > 250 AND UnitPrice * Quantity <= 500
Select COUNT(DISTINCT(OrderID)) as JumlahOrderID FROM [Order Details] WHERE UnitPrice * Quantity > 500