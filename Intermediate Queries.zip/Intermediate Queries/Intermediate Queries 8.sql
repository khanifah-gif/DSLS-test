Create View Detail_Order
as
Select
OrderID,
[Order Details].ProductID,
ProductName,
Products.UnitPrice,
Quantity, Discount,
(Products.UnitPrice * Quantity) - Discount as Harga_Setelah_Diskon
from [Order Details]
JOIN Products ON [Order Details].ProductID = Products.ProductID

Select * From Detail_Order