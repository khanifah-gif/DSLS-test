Create Procedure prosedur_invoice
	@IdCustomer VARCHAR(10)

As
Begin
 Select Orders.CustomerID, CompanyName, OrderID, OrderDate, RequiredDate, ShippedDate
 From Orders
 JOIN Customers
 ON Orders.CustomerID = Customers.CustomerID
 Where Orders.CustomerID=@IdCustomer;
 End

 Exec prosedur_invoice 'VINET'