Select TOP 5 ProductName, CategoryName, Quantity From Orders
JOIN [Order Details]
ON Orders.OrderID = [Order Details].OrderID
JOIN Products
ON [Order Details].ProductID = Products.ProductID
JOIN Categories
ON Products.CategoryID = Categories.CategoryID
WHERE MONTH(OrderDate) = 1 AND YEAR(OrderDate) = 1997 Order By Quantity Desc