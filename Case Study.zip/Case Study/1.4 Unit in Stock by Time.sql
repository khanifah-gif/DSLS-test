-- Prosedur_UnitInStockByWaktu
Select ProductName, CategoryName, UnitsInStock From Orders
JOIN [Order Details] ON Orders.OrderID = [Order Details].OrderID
JOIN Products ON [Order Details].ProductID = Products.ProductID
JOIN Categories ON Products.CategoryID = Categories.CategoryID
WHERE MONTH(OrderDate) = 12 AND Year(OrderDate) = 1997