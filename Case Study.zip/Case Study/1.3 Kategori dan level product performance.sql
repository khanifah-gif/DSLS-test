Select CategoryName, SUM(Quantity) as TotalQuantity,
SUM([Order Details].UnitPrice*Quantity) as NetRevenue,
SUM(Discount) as Diskon, SUM(([Order Details].UnitPrice*Quantity) - Discount) as GrossRevenue
From Orders JOIN [Order Details] ON Orders.OrderID = [Order Details].OrderID
JOIN Products ON [Order Details].ProductID = Products.ProductID
JOIN Categories ON Products.CategoryID = Categories.CategoryID
WHERE Month(OrderDate) = 12 AND Year(OrderDate) = 1997 GROUP BY CategoryName Order By TotalQuantity Desc