Select Orders.EmployeeID, COUNT(Orders.EmployeeID) as JumlahClosing
From Orders
WHERE MONTH(OrderDate) = 12 AND YEAR(OrderDate) = 1997
Group By Orders.EmployeeID