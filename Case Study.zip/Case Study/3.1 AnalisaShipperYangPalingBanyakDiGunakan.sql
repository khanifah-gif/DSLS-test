--Count Shipper Tahun 1997
Select CompanyName, COUNT(ShipperID) as Jumlah From Orders JOIN Shippers ON Orders.ShipVia = Shippers.ShipperID
Where Year(OrderDate) = 1997 Group By CompanyName