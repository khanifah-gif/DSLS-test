Select Title, SUM(Quantity) as Quantity,
SUM(UnitPrice * Quantity) as NetRevenue,
SUM(Discount) as Diskon,
SUM((UnitPrice * Quantity) - Discount) as GrossRevenue
From Orders
JOIN [Order Details] ON Orders.OrderID = [Order Details].OrderID
JOIN Employees ON Orders.EmployeeID = Employees.EmployeeID
WHERE YEAR(OrderDate) = 1997
Group By Title