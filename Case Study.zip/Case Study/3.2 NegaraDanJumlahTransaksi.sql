Select ShipCountry, COUNT(ShipCountry) as JumlahTransaksi
From Orders Where Year(OrderDate) = 1997 Group By ShipCountry Order By ShipCountry Asc